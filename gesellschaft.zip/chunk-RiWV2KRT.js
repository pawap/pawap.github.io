import{t as e}from"./chunk-CgQDO-0U.js";var r=`fogVertexDeclaration`;var o=`#ifdef FOG
varying vFogDistance: vec3f;
#endif
`;e.IncludesShadersStoreWGSL[r]||(e.IncludesShadersStoreWGSL[r]=o);var a={name:r,shader:o};export{a as t};