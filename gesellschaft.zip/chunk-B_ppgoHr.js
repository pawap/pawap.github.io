import{t as e$1}from"./chunk-CgQDO-0U.js";var e=`fogFragment`;var r=`#ifdef FOG
float fog=CalcFogFactor();
#ifdef PBR
fog=toLinearSpace(fog);
#endif
color.rgb=mix(vFogColor,color.rgb,fog);
#endif
`;e$1.IncludesShadersStore[e]||(e$1.IncludesShadersStore[e]=r);var t={name:e,shader:r};export{t};