import{t as e}from"./chunk-CgQDO-0U.js";var o=`sceneUboDeclaration`;var t=`struct Scene {viewProjection : mat4x4<f32>,
#ifdef MULTIVIEW
viewProjectionR : mat4x4<f32>,
#endif 
view : mat4x4<f32>,
projection : mat4x4<f32>,
vEyePosition : vec4<f32>,
inverseProjection : mat4x4<f32>,
previousViewProjection : mat4x4<f32>,
taaJitter : vec2<f32>,};
#define SCENE_UBO
var<uniform> scene : Scene;
`;e.IncludesShadersStoreWGSL[o]||(e.IncludesShadersStoreWGSL[o]=t);var r={name:o,shader:t};export{r as t};