import{t as e}from"./chunk-CgQDO-0U.js";var t=`logDepthFragment`;var r=`#ifdef LOGARITHMICDEPTH
gl_FragDepthEXT=log2(vFragmentDepth)*logarithmicDepthConstant*0.5;
#endif
`;e.IncludesShadersStore[t]||(e.IncludesShadersStore[t]=r);var n={name:t,shader:r};export{n as t};