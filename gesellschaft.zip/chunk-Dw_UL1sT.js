import{t as e}from"./chunk-CgQDO-0U.js";var o=`fogVertex`;var r=`#ifdef FOG
vFogDistance=(view*worldPos).xyz;
#endif
`;e.IncludesShadersStore[o]||(e.IncludesShadersStore[o]=r);var s={name:o,shader:r};export{s as t};