import{t as e}from"./chunk-CgQDO-0U.js";import{t}from"./chunk-DqERNKmj.js";import{t as r$1}from"./chunk-DLh_ER_g.js";var r=`volumetricLightingRenderVolumeVertexShader`;var s=`#include<sceneUboDeclaration>
#include<meshUboDeclaration>
attribute position : vec3f;varying vWorldPos: vec4f;@vertex
fn main(input : VertexInputs)->FragmentInputs {let worldPos=mesh.world*vec4f(vertexInputs.position,1.0);vertexOutputs.vWorldPos=worldPos;vertexOutputs.position=scene.viewProjection*worldPos;}
`;e.ShadersStoreWGSL[r]||(e.ShadersStoreWGSL[r]=s);var i=[r$1,t];for(let o of i)e.IncludesShadersStoreWGSL[o.name]||(e.IncludesShadersStoreWGSL[o.name]=o.shader);var l={name:r,shader:s};export{l as volumetricLightingRenderVolumeVertexShaderWGSL};