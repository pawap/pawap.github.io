import{a}from"./chunk-JZF5SSMK.js";import"./chunk-L5WUWJUF.js";import"./chunk-EGDUX52C.js";export{a as rsmFullGlobalIlluminationPixelShader};
