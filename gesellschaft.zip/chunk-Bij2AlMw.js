import{t as e$1}from"./chunk-CgQDO-0U.js";var e=`boundingBoxRendererUboDeclaration`;var r=`#ifdef WEBGL2
uniform vec4 color;uniform mat4 world;uniform mat4 viewProjection;
#ifdef MULTIVIEW
uniform mat4 viewProjectionR;
#endif
#else
layout(std140,column_major) uniform;uniform BoundingBoxRenderer {vec4 color;mat4 world;mat4 viewProjection;mat4 viewProjectionR;};
#endif
`;e$1.IncludesShadersStore[e]||(e$1.IncludesShadersStore[e]=r);var i={name:e,shader:r};export{i as t};