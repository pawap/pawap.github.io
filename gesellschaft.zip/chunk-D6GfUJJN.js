import{t as e}from"./chunk-CgQDO-0U.js";var r=`morphTargetsVertexGlobal`;var o=`#ifdef MORPHTARGETS
#ifdef MORPHTARGETS_TEXTURE
float vertexID;
#endif
#endif
`;e.IncludesShadersStore[r]||(e.IncludesShadersStore[r]=o);var a={name:r,shader:o};export{a as t};