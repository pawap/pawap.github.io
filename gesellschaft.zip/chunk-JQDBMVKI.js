import{a}from"./chunk-PUAH6ZKQ.js";import"./chunk-L5WUWJUF.js";import"./chunk-EGDUX52C.js";export{a as highlightsPixelShaderWGSL};
