import{a}from"./chunk-PYI72UF7.js";import"./chunk-L5WUWJUF.js";import"./chunk-EGDUX52C.js";export{a as rsmGlobalIlluminationPixelShader};
