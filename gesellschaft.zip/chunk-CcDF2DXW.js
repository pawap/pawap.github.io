import{t as e$1}from"./chunk-CgQDO-0U.js";var e=`meshUboDeclaration`;var i=`#ifdef WEBGL2
uniform mat4 world;uniform float visibility;
#else
layout(std140,column_major) uniform;uniform Mesh
{mat4 world;float visibility;};
#endif
#define WORLD_UBO
`;e$1.IncludesShadersStore[e]||(e$1.IncludesShadersStore[e]=i);var t={name:e,shader:i};export{t};