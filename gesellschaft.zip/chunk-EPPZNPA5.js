import{a as e}from"./chunk-L5WUWJUF.js";import"./chunk-EGDUX52C.js";var r="handlePixelShader",t=`uniform color: vec3f;@fragment
fn main(input: FragmentInputs)->FragmentOutputs {fragmentOutputs.color=vec4f(uniforms.color,1.0);}
`;e.ShadersStoreWGSL[r]||(e.ShadersStoreWGSL[r]=t);var n={name:r,shader:t};export{n as handlePixelShaderWGSL};
