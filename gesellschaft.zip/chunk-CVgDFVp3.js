import{t as e$1}from"./chunk-CgQDO-0U.js";var r=`fogFragment`;var e=`#ifdef FOG
var fog: f32=CalcFogFactor();
#ifdef PBR
fog=toLinearSpace(fog);
#endif
color= vec4f(mix(uniforms.vFogColor,color.rgb,fog),color.a);
#endif
`;e$1.IncludesShadersStoreWGSL[r]||(e$1.IncludesShadersStoreWGSL[r]=e);var a={name:r,shader:e};export{a as t};