import{t as e$1}from"./chunk-CgQDO-0U.js";var e=`logDepthFragment`;var r=`#ifdef LOGARITHMICDEPTH
fragmentOutputs.fragDepth=log2(fragmentInputs.vFragmentDepth)*uniforms.logarithmicDepthConstant*0.5;
#endif
`;e$1.IncludesShadersStoreWGSL[e]||(e$1.IncludesShadersStoreWGSL[e]=r);var o={name:e,shader:r};export{o as t};