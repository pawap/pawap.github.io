import{a as e}from"./chunk-L5WUWJUF.js";import"./chunk-EGDUX52C.js";var r="textureMergerPixelShader",t=`#ifdef USE_TEXTURE0
var inputTexture0Sampler: sampler;var inputTexture0: texture_2d<f32>;
#ifdef TEXTURE0_MATRIX
uniform inputTexture0Matrix: mat4x4f;
#endif
#endif
#ifdef USE_TEXTURE1
var inputTexture1Sampler: sampler;var inputTexture1: texture_2d<f32>;
#ifdef TEXTURE1_MATRIX
uniform inputTexture1Matrix: mat4x4f;
#endif
#endif
#ifdef USE_TEXTURE2
var inputTexture2Sampler: sampler;var inputTexture2: texture_2d<f32>;
#ifdef TEXTURE2_MATRIX
uniform inputTexture2Matrix: mat4x4f;
#endif
#endif
#ifdef USE_TEXTURE3
var inputTexture3Sampler: sampler;var inputTexture3: texture_2d<f32>;
#ifdef TEXTURE3_MATRIX
uniform inputTexture3Matrix: mat4x4f;
#endif
#endif
#ifdef RED_FROM_TEXTURE
uniform redTextureIndex: i32;uniform redSourceChannel: i32;
#else
uniform redConstantValue: f32;
#endif
#ifdef GREEN_FROM_TEXTURE
uniform greenTextureIndex: i32;uniform greenSourceChannel: i32;
#else
uniform greenConstantValue: f32;
#endif
#ifdef BLUE_FROM_TEXTURE
uniform blueTextureIndex: i32;uniform blueSourceChannel: i32;
#else
uniform blueConstantValue: f32;
#endif
#ifdef ALPHA_FROM_TEXTURE
uniform alphaTextureIndex: i32;uniform alphaSourceChannel: i32;
#else
uniform alphaConstantValue: f32;
#endif
varying vUV: vec2f;
#if defined(RED_FROM_TEXTURE) || defined(GREEN_FROM_TEXTURE) || defined(BLUE_FROM_TEXTURE) || defined(ALPHA_FROM_TEXTURE)
fn sampleTexture(textureIndex: i32,uv: vec2f)->vec4f {switch (textureIndex) {
#ifdef USE_TEXTURE0
case 0: {
#ifdef TEXTURE0_MATRIX
return textureSample(inputTexture0,inputTexture0Sampler,(uniforms.inputTexture0Matrix*vec4f(uv,1.0,0.0)).xy);
#else
return textureSample(inputTexture0,inputTexture0Sampler,uv);
#endif
}
#endif
#ifdef USE_TEXTURE1
case 1: {
#ifdef TEXTURE1_MATRIX
return textureSample(inputTexture1,inputTexture1Sampler,(uniforms.inputTexture1Matrix*vec4f(uv,1.0,0.0)).xy);
#else
return textureSample(inputTexture1,inputTexture1Sampler,uv);
#endif
}
#endif
#ifdef USE_TEXTURE2
case 2: {
#ifdef TEXTURE2_MATRIX
return textureSample(inputTexture2,inputTexture2Sampler,(uniforms.inputTexture2Matrix*vec4f(uv,1.0,0.0)).xy);
#else
return textureSample(inputTexture2,inputTexture2Sampler,uv);
#endif
}
#endif
#ifdef USE_TEXTURE3
case 3: {
#ifdef TEXTURE3_MATRIX
return textureSample(inputTexture3,inputTexture3Sampler,(uniforms.inputTexture3Matrix*vec4f(uv,1.0,0.0)).xy);
#else
return textureSample(inputTexture3,inputTexture3Sampler,uv);
#endif
}
#endif
default: {return vec4f(0.0,0.0,0.0,1.0); }}}
fn extractChannel(color: vec4f,channelIndex: i32)->f32 {switch (channelIndex) {case 0: {return color.r; }
case 1: {return color.g; }
case 2: {return color.b; }
default: {return color.a; }}}
#endif
@fragment
fn main(input: FragmentInputs)->FragmentOutputs {let uv: vec2f=input.vUV;
#ifdef RED_FROM_TEXTURE
let redSample: vec4f=sampleTexture(uniforms.redTextureIndex,uv);let r: f32=extractChannel(redSample,uniforms.redSourceChannel);
#else
let r: f32=uniforms.redConstantValue;
#endif
#ifdef GREEN_FROM_TEXTURE
let greenSample: vec4f=sampleTexture(uniforms.greenTextureIndex,uv);let g: f32=extractChannel(greenSample,uniforms.greenSourceChannel);
#else
let g: f32=uniforms.greenConstantValue;
#endif
#ifdef BLUE_FROM_TEXTURE
let blueSample: vec4f=sampleTexture(uniforms.blueTextureIndex,uv);let b: f32=extractChannel(blueSample,uniforms.blueSourceChannel);
#else
let b: f32=uniforms.blueConstantValue;
#endif
#ifdef ALPHA_FROM_TEXTURE
let alphaSample: vec4f=sampleTexture(uniforms.alphaTextureIndex,uv);let a: f32=extractChannel(alphaSample,uniforms.alphaSourceChannel);
#else
let a: f32=uniforms.alphaConstantValue;
#endif
fragmentOutputs.color=vec4f(r,g,b,a);}`;e.ShadersStoreWGSL[r]||(e.ShadersStoreWGSL[r]=t);var u={name:r,shader:t};export{u as textureMergerPixelShaderWGSL};
